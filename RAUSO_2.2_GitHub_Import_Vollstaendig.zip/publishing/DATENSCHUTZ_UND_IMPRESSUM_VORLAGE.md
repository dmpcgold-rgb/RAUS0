# RAUSO – ENTWURF, nicht veröffentlichungsfähig

Folgende Betreiberangaben müssen durch die Betreiberin eingetragen und geprüft werden:
- Name und ladungsfähige Anschrift
- Kontakt-E-Mail für Support, Datenschutz, Löschung und Meldungen
- Unternehmensform, gegebenenfalls Firmenbuch-/UID-Angaben
- Eingesetzte Auftragsverarbeiter (z. B. Supabase, Firebase, Kartenanbieter), Regionen, Übermittlungen
- Zwecke, Datenarten, Rechtsgrundlagen, Empfänger, Aufbewahrungs- und Löschfristen
- Betroffenenrechte nach DSGVO und Datenschutzbehördenkontakt
- Jugendschutz, Sichtbarkeit von Profilen, Treffendaten, Fotos, Chats und Standortdetails
- Getrennte Angaben für fakultatives Dating und gegebenenfalls Altersverifikation

## Kontolöschung
Innerhalb der App und über eine öffentlich erreichbare Webseite mit authentifizierbarem Antrag. Nach Antrag Identität angemessen prüfen, personenbezogene Daten und Speicherobjekte nach einer dokumentierten Löschroutine entfernen, gesetzliche Aufbewahrungspflichten transparent nennen. Eine bloße lokale Profilzurücksetzung genügt nicht.

Diese Vorlage ersetzt keine Prüfung nach DSGVO/österreichischem Recht.
