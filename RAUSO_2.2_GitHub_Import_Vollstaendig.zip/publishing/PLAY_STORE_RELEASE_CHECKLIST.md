# RAUSO – verbindliche Freigabeschritte (Stand 22.10.2026)

## Technischer Mindeststand
- [x] Android `compileSdk/targetSdk` = 36, Version 1.9.0.
- [x] GitHub Actions: Test-APK plus **unsigniertes** Release-AAB.
- [ ] Separates RAUSO-Supabase-Projekt anlegen und alle SQL-Migrationen kontrolliert anwenden.
- [ ] Beide Betreiber registrieren; `owner` und `admin` ausschließlich privilegiert zuweisen und Zugriffe prüfen.
- [ ] Auth-RLS, Moderation, Kontolöschung und Uploadberechtigungen mit zwei Testkonten Ende-zu-Ende testen.
- [ ] Push-Benachrichtigungen: FCM, Berechtigung zur Laufzeit und sicheren serverseitigen Versand implementieren/testen.
- [ ] Echte ortsbezogene Datendienste und Nutzungslimits/Lizenzen festlegen; Kinoprogramm nur nach legaler Partnerfreigabe.
- [ ] Datenerklärung/Impressum, DSGVO-Verzeichnis, Auftragsverarbeitung, Löschfristen und Sicherheit juristisch prüfen.
- [ ] Öffentliche Webseite mit Kontolöschungs-Antragsmöglichkeit und In-App-Löschung bereitstellen; Serverprozesse testen.
- [ ] Nutzerinhalte: Melden, Blockieren, Moderation und Minderjährigenschutz real testen.
- [ ] Opt-in-Dating nur mit wirksamer Alterskontrolle aktivieren; bis dahin abschalten.
- [ ] Store-Screenshots/Feature-Grafik aus echten geprüften App-Bildschirmen erstellen.
- [ ] Release-Keystore sicher erzeugen, sichern; signiertes **AAB** mit Play App Signing hochladen.
- [ ] Data-Safety, Zielgruppe, Inhaltsfreigabe, Datenschutz-URL und Kontolöschungs-URL im Play Console ausfüllen.
- [ ] Geschlossene Tests nach Kontotypvorgaben in Play Console, anschließend Review.

## Rechte
Betreiberin: **owner**, zusätzlicher Mitadministrator: **admin**. Keine heimlichen Admin-Zugänge. UUIDs nur nach echter Registrierung und Zustimmung eintragen.

## Achtung
Das Workflow-AAB ist **unsigniert** und nicht direkt im Play Store einreichbar. Eine erfolgreich gebaute Test-APK belegt keine Produktivreife.
