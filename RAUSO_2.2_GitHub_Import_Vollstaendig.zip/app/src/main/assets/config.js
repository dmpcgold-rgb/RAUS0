// Fill in ONLY the URL and public publishable key of a NEW dedicated Supabase project.
// Never put service_role / sb_secret keys or a database password here.
window.ERLEBEN_CONFIG = {
  supabaseUrl: "",
  supabasePublishableKey: ""
};
