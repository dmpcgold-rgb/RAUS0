/* RAUSO 1.6: new features are incorporated in app.js. */
