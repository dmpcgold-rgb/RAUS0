-- RAUSO v1.2 security additions. Run AFTER backend/schema.sql in an isolated Supabase project.
-- No self-service process may mark identity or vehicle data "verified".
-- Configure a vetted KYC/KYB document provider, use signed server-side callbacks, and
-- audit/validate every provider response BEFORE a trusted backend writes these tables.
-- No scans, biometric templates or selfie images are stored in this database schema.

create table if not exists public.identity_checks (
  user_id uuid primary key references auth.users(id) on delete cascade,
  status text not null default 'not_started' check(status in ('not_started','pending','verified','rejected','expired')),
  legal_name text not null default '',
  document_valid boolean not null default false,
  face_match boolean not null default false,
  liveness_ok boolean not null default false,
  provider_reference text,
  checked_at timestamptz,
  updated_at timestamptz not null default now()
);
create table if not exists public.vehicle_checks (
  user_id uuid primary key references auth.users(id) on delete cascade,
  status text not null default 'not_started' check(status in ('not_started','pending','verified','rejected','expired')),
  plate text not null default '',
  registration_holder_name text not null default '',
  registration_document_valid boolean not null default false,
  document_plate_matches boolean not null default false,
  provider_reference text,
  checked_at timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.identity_checks enable row level security;
alter table public.vehicle_checks enable row level security;
revoke all on public.identity_checks from public, anon, authenticated;
revoke all on public.vehicle_checks from public, anon, authenticated;
grant all on public.identity_checks to service_role;
grant all on public.vehicle_checks to service_role;
-- Trusted server must use role privileges with RLS bypass (service_role) and must never
-- expose its credentials or verification write endpoints to untrusted browser JS.

create or replace function public.is_verified_user(check_user uuid)
returns boolean language sql stable security definer set search_path = '' as $$
 select exists (
   select 1 from public.identity_checks i
   join public.profiles p on p.id=i.user_id
   where i.user_id=check_user and i.status='verified'
     and i.document_valid and i.face_match and i.liveness_ok
     and lower(btrim(i.legal_name))=lower(btrim(p.display_name))
     and length(btrim(i.legal_name)) >= 2
 );
$$;
create or replace function public.is_verified_driver(check_user uuid)
returns boolean language sql stable security definer set search_path = '' as $$
 select public.is_verified_user(check_user) and exists (
   select 1 from public.vehicle_checks v
   join public.identity_checks i on i.user_id=v.user_id
   where v.user_id=check_user and v.status='verified'
     and v.registration_document_valid and v.document_plate_matches
     and length(btrim(v.plate))>2
     and lower(btrim(v.registration_holder_name))=lower(btrim(i.legal_name))
 );
$$;
-- Returns only pass/fail statuses, not ID scans, plate numbers or identity evidence.
create or replace function public.my_verification_status()
returns jsonb language sql stable security definer set search_path = '' as $$
 select jsonb_build_object(
  'identity_status',case when public.is_verified_user(auth.uid()) then 'verified' when (select i.status from public.identity_checks i where i.user_id=auth.uid())='verified' then 'rejected' else coalesce((select i.status from public.identity_checks i where i.user_id=auth.uid()),'not_started') end,
  'face_match',public.is_verified_user(auth.uid()),
  'name_match',public.is_verified_user(auth.uid()),
  'vehicle_status',case when public.is_verified_driver(auth.uid()) then 'verified' when (select v.status from public.vehicle_checks v where v.user_id=auth.uid())='verified' then 'rejected' else coalesce((select v.status from public.vehicle_checks v where v.user_id=auth.uid()),'not_started') end,
  'vehicle_match',public.is_verified_driver(auth.uid()),
  'plate_match',public.is_verified_driver(auth.uid())
 );
$$;
revoke execute on function public.is_verified_user(uuid) from public, anon;
revoke execute on function public.is_verified_driver(uuid) from public, anon;
revoke execute on function public.my_verification_status() from public, anon;
grant execute on function public.my_verification_status() to authenticated;
grant execute on function public.is_verified_user(uuid) to authenticated;
grant execute on function public.is_verified_driver(uuid) to authenticated;
-- Internal predicates are invoked by policies as SECURITY DEFINER. Keep direct usage unavailable to anonymous clients.

create or replace function public.lock_checked_legal_name()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
 if old.display_name is distinct from new.display_name
   and exists(select 1 from public.identity_checks i where i.user_id=old.id and i.status='verified') then
   raise exception 'Verifizierter Profilname kann nicht selbst geändert werden';
 end if;
 return new;
end;
$$;
drop trigger if exists lock_checked_legal_name on public.profiles;
create trigger lock_checked_legal_name before update on public.profiles
for each row execute function public.lock_checked_legal_name();

alter table public.outings add column if not exists visibility text not null default 'public' check (visibility in ('public','private'));
alter table public.outings add column if not exists meeting_type text check(meeting_type is null or meeting_type in('kochen','basteln','backen','spiele','kaffee','sonstiges'));
alter table public.outings add column if not exists transport_mode text not null default 'zufuss' check(transport_mode in('auto','ubahn','bus','zug','zufuss'));
alter table public.outings add column if not exists ride_role text not null default 'none' check(ride_role in('none','seek','offer'));
alter table public.outings add column if not exists departure_place text not null default '' check(char_length(departure_place)<=160);
alter table public.outings add column if not exists transport_line text not null default '' check(char_length(transport_line)<=80);
alter table public.outings add column if not exists seats_offered int check(seats_offered is null or seats_offered between 1 and 6);
alter table public.outings drop constraint if exists ride_role_only_car;
alter table public.outings add constraint ride_role_only_car
 check ((ride_role='none' or transport_mode='auto') and (ride_role!='offer' or seats_offered is not null));
grant insert on public.outings to authenticated;
-- Existing schema allows update on older columns only; do not grant client writes to verified fields.

-- Existing policies in schema.sql are redefined. Unverified members may view safe public
-- discovery data but cannot create, attend, chat, or match using the Data API.
drop policy if exists "profiles visible to members" on public.profiles;
create policy "profiles visible to members" on public.profiles for select to authenticated
 using (id=auth.uid() or public.is_verified_user(id));
drop policy if exists "outings visible to members" on public.outings;
create policy "outings visible to members" on public.outings for select to authenticated
 using (public.is_verified_user(author_id));
drop policy if exists "own outing insert" on public.outings;
create policy "own outing insert" on public.outings for insert to authenticated with check (
 author_id=auth.uid() and public.is_verified_user(auth.uid())
 and (ride_role!='offer' or public.is_verified_driver(auth.uid()))
);
drop policy if exists "react as self" on public.outing_reactions;
create policy "react as self" on public.outing_reactions for insert to authenticated with check (
 user_id=auth.uid() and public.is_verified_user(auth.uid())
);
drop policy if exists "update own reaction" on public.outing_reactions;
create policy "update own reaction" on public.outing_reactions for update to authenticated
 using (user_id=auth.uid() and public.is_verified_user(auth.uid()))
 with check(user_id=auth.uid() and public.is_verified_user(auth.uid()));
drop policy if exists "request from self" on public.connections;
create policy "request from self" on public.connections for insert to authenticated with check (
 sender_id=auth.uid() and status='pending' and public.is_verified_user(auth.uid()) and public.is_verified_user(receiver_id)
);
drop policy if exists "receiver answers" on public.connections;
create policy "receiver answers" on public.connections for update to authenticated
 using(receiver_id=auth.uid() and status='pending' and public.is_verified_user(auth.uid()))
 with check(receiver_id=auth.uid() and status in ('accepted','declined') and public.is_verified_user(auth.uid()));
drop policy if exists "dating like own" on public.dating_likes;
create policy "dating like own" on public.dating_likes for insert to authenticated with check (
 liker_id=auth.uid() and public.is_verified_user(liker_id) and public.is_verified_user(liked_id)
 and exists(select 1 from public.profiles p where p.id=liker_id and p.dating_enabled and p.adult_confirmed)
 and exists(select 1 from public.profiles p where p.id=liked_id and p.dating_enabled and p.adult_confirmed)
);
drop policy if exists "send only to connected users" on public.messages;
create policy "send only to connected users" on public.messages for insert to authenticated with check (
 sender_id=auth.uid() and public.is_verified_user(sender_id) and public.is_verified_user(recipient_id)
 and not exists (select 1 from public.blocks b where
  (b.blocker_id=sender_id and b.blocked_id=recipient_id) or
  (b.blocker_id=recipient_id and b.blocked_id=sender_id))
 and (
  exists(select 1 from public.connections c where c.status='accepted' and
    ((c.sender_id=sender_id and c.receiver_id=recipient_id) or (c.sender_id=recipient_id and c.receiver_id=sender_id)))
  or (
   exists(select 1 from public.dating_likes a join public.dating_likes b
     on b.liker_id=a.liked_id and b.liked_id=a.liker_id
    where a.liker_id=sender_id and a.liked_id=recipient_id)
   and exists(select 1 from public.profiles p where p.id=sender_id and p.dating_enabled and p.adult_confirmed)
   and exists(select 1 from public.profiles p where p.id=recipient_id and p.dating_enabled and p.adult_confirmed)
  )
 )
);
-- Force verified identity before turning on dating; age must also be confirmed by a trusted provider in production.
create or replace function public.prevent_unverified_dating()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
 if new.dating_enabled and not public.is_verified_user(new.id) then
  raise exception 'Dating benötigt eine verifizierte Identität';
 end if;
 return new;
end;
$$;
drop trigger if exists prevent_unverified_dating on public.profiles;
create trigger prevent_unverified_dating before update on public.profiles
for each row execute function public.prevent_unverified_dating();

-- Non-public incident report, evidence link and driver-vehicle snapshot.
-- Neither original ID evidence nor raw face data is stored here.
create table if not exists public.incident_reports (
 id uuid primary key default gen_random_uuid(),
 reporter_id uuid not null references auth.users(id),
 outing_id uuid,
 reported_driver_id uuid,
 trip_start timestamptz,
 trip_public_location text,
 kind text not null check(kind in ('danger','missing','identity','other')),
 description text not null check(char_length(description) between 10 and 1500),
 created_at timestamptz not null default now()
);
create table if not exists public.ride_audit (
 outing_id uuid primary key,
 driver_id uuid not null,
 plate text not null,
 identity_provider_reference text,
 vehicle_provider_reference text,
 verified_at timestamptz not null default now()
);
alter table public.incident_reports enable row level security;
alter table public.ride_audit enable row level security;
revoke all on public.incident_reports from public,anon,authenticated;
revoke all on public.ride_audit from public,anon,authenticated;
grant all on public.ride_audit to service_role;
grant all on public.incident_reports to service_role;
grant select,insert on public.incident_reports to authenticated;
create policy "own private incident reports" on public.incident_reports for select to authenticated using(reporter_id=auth.uid());
create policy "report incident as self" on public.incident_reports for insert to authenticated
 with check (reporter_id=auth.uid());

create or replace function public.capture_driver_evidence()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
 if new.ride_role='offer' then
   if not public.is_verified_driver(new.author_id) then raise exception 'Driver not verified'; end if;
   insert into public.ride_audit(outing_id,driver_id,plate,identity_provider_reference,vehicle_provider_reference)
   select new.id,new.author_id,v.plate,i.provider_reference,v.provider_reference
   from public.vehicle_checks v join public.identity_checks i on i.user_id=v.user_id
   where v.user_id=new.author_id;
 end if;
 return new;
end;
$$;
drop trigger if exists capture_driver_evidence on public.outings;
create trigger capture_driver_evidence after insert on public.outings
for each row execute function public.capture_driver_evidence();

-- This function intentionally uses no client-supplied identity for an identified driver.
-- An outing ID may be supplied; relevant existing metadata is snapshotted for review.
-- Append-only participant trace for review after an incident. Not exposed through client API.
create table if not exists public.participation_audit (
 id uuid primary key default gen_random_uuid(),
 outing_id uuid not null,
 user_id uuid not null,
 reaction text not null,
 operation text not null,
 occurred_at timestamptz not null default now()
);
alter table public.participation_audit enable row level security;
revoke all on public.participation_audit from public,anon,authenticated;
grant all on public.participation_audit to service_role;
create or replace function public.capture_participation_audit()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
 if tg_op='DELETE' then
  insert into public.participation_audit(outing_id,user_id,reaction,operation)
  values(old.outing_id,old.user_id,old.reaction,'DELETE');
  return old;
 else
  insert into public.participation_audit(outing_id,user_id,reaction,operation)
  values(new.outing_id,new.user_id,new.reaction,tg_op);
  return new;
 end if;
end;
$$;
drop trigger if exists capture_participation_audit on public.outing_reactions;
create trigger capture_participation_audit after insert or update or delete on public.outing_reactions
for each row execute function public.capture_participation_audit();

create or replace function public.capture_incident_context()
returns trigger language plpgsql security definer set search_path = '' as $$
declare o public.outings%rowtype;
begin
 if new.outing_id is not null then
   select * into o from public.outings where id=new.outing_id;
   if not found then raise exception 'Unknown outing'; end if;
   new.reported_driver_id := o.author_id;
   new.trip_start := o.starts_at;
   new.trip_public_location := o.place_name;
 end if;
 return new;
end;
$$;
drop trigger if exists capture_incident_context on public.incident_reports;
create trigger capture_incident_context before insert on public.incident_reports
for each row execute function public.capture_incident_context();

-- Operator access: only via backend/service role with manual incident triage, lawful
-- authority requests, access audit, encrypted storage and documented retention limits.
-- Do not permit arbitrary user lookup of identities/plates in client code.
