-- Österreich Erleben v1: run in a NEW, dedicated Supabase project.
-- This schema intentionally does not touch existing Gym Coach or other projects.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 2 and 40),
  city text not null default '' check (char_length(city) <= 80),
  bio text not null default '' check (char_length(bio) <= 500),
  dating_enabled boolean not null default false,
  adult_confirmed boolean not null default false,
  created_at timestamptz not null default now(),
  constraint dating_requires_adult check (not dating_enabled or adult_confirmed)
);
create table if not exists public.outings (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 4 and 100),
  description text not null default '' check (char_length(description) <= 1200),
  place_name text not null check (char_length(place_name) between 2 and 160),
  lat double precision check (lat between 46 and 50),
  lon double precision check (lon between 9 and 18),
  starts_at timestamptz not null,
  category text not null default 'ausfluege' check (category in ('restaurants','thermen','ausfluege','natur','kultur','uebernachten','sport','familie')),
  family_friendly boolean not null default false,
  capacity int check (capacity is null or capacity between 2 and 100),
  created_at timestamptz not null default now()
);
create table if not exists public.outing_reactions (
  outing_id uuid not null references public.outings(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  reaction text not null check (reaction in ('like','interested','going')),
  created_at timestamptz not null default now(),
  primary key(outing_id,user_id)
);
create table if not exists public.connections (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined')),
  created_at timestamptz not null default now(),
  check (sender_id <> receiver_id)
);
create unique index if not exists connections_pair_uq on public.connections(least(sender_id,receiver_id),greatest(sender_id,receiver_id));
create table if not exists public.dating_likes (
  liker_id uuid not null references public.profiles(id) on delete cascade,
  liked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(liker_id,liked_id),
  check(liker_id<>liked_id)
);
create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(blocker_id, blocked_id),
  check(blocker_id<>blocked_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now(),
  check(sender_id <> recipient_id)
);
create index if not exists messages_pair_idx on public.messages(sender_id,recipient_id,created_at desc);
create index if not exists messages_received_idx on public.messages(recipient_id,created_at desc);
create index if not exists outings_starts_idx on public.outings(starts_at);
create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  target_id uuid not null references public.profiles(id) on delete cascade,
  reason text not null check (char_length(reason) between 5 and 500),
  created_at timestamptz not null default now(),
  check(reporter_id<>target_id)
);

alter table public.profiles enable row level security;
alter table public.outings enable row level security;
alter table public.outing_reactions enable row level security;
alter table public.connections enable row level security;
alter table public.dating_likes enable row level security;
alter table public.blocks enable row level security;
alter table public.messages enable row level security;
alter table public.reports enable row level security;

-- Explicit grants are needed when the Data API does not apply default grants.
grant usage on schema public to authenticated;
grant select, insert, delete on public.profiles to authenticated;
grant update(display_name, city, bio, dating_enabled, adult_confirmed) on public.profiles to authenticated;
grant select, insert, delete on public.outings to authenticated;
grant update(title, description, place_name, lat, lon, starts_at, category, family_friendly, capacity) on public.outings to authenticated;
grant select, insert, update, delete on public.outing_reactions to authenticated;
grant select, insert, delete on public.connections to authenticated;
grant update(status) on public.connections to authenticated;
grant select, insert, delete on public.dating_likes to authenticated;
grant select, insert, delete on public.blocks to authenticated;
grant select, insert on public.messages to authenticated;
grant select, insert on public.reports to authenticated;

create policy "profiles visible to members" on public.profiles for select to authenticated using (true);
create policy "create own profile" on public.profiles for insert to authenticated with check (id = (select auth.uid()));
create policy "update own profile" on public.profiles for update to authenticated using (id=(select auth.uid())) with check(id=(select auth.uid()));
create policy "delete own profile" on public.profiles for delete to authenticated using (id=(select auth.uid()));

create policy "outings visible to members" on public.outings for select to authenticated using (true);
create policy "own outing insert" on public.outings for insert to authenticated with check(author_id=(select auth.uid()));
create policy "own outing update" on public.outings for update to authenticated using(author_id=(select auth.uid())) with check(author_id=(select auth.uid()));
create policy "own outing delete" on public.outings for delete to authenticated using(author_id=(select auth.uid()));

create policy "reactions visible to members" on public.outing_reactions for select to authenticated using (true);
create policy "react as self" on public.outing_reactions for insert to authenticated with check(user_id=(select auth.uid()));
create policy "update own reaction" on public.outing_reactions for update to authenticated using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));
create policy "delete own reaction" on public.outing_reactions for delete to authenticated using(user_id=(select auth.uid()));

create policy "connection participants read" on public.connections for select to authenticated using(sender_id=(select auth.uid()) or receiver_id=(select auth.uid()));
create policy "request from self" on public.connections for insert to authenticated with check(sender_id=(select auth.uid()) and status='pending');
create policy "receiver answers" on public.connections for update to authenticated using(receiver_id=(select auth.uid()) and status='pending') with check(receiver_id=(select auth.uid()) and status in ('accepted','declined'));
create policy "participants remove connection" on public.connections for delete to authenticated using(sender_id=(select auth.uid()) or receiver_id=(select auth.uid()));

create policy "dating likes participants read" on public.dating_likes for select to authenticated using(liker_id=(select auth.uid()) or liked_id=(select auth.uid()));
create policy "dating like own" on public.dating_likes for insert to authenticated with check (
  liker_id=(select auth.uid()) and
  exists(select 1 from public.profiles p where p.id=liker_id and p.dating_enabled and p.adult_confirmed) and
  exists(select 1 from public.profiles p where p.id=liked_id and p.dating_enabled and p.adult_confirmed)
);
create policy "remove own dating like" on public.dating_likes for delete to authenticated using(liker_id=(select auth.uid()));

create policy "blocks participants read" on public.blocks for select to authenticated using(blocker_id=(select auth.uid()) or blocked_id=(select auth.uid()));
create policy "block other person" on public.blocks for insert to authenticated with check(blocker_id=(select auth.uid()));
create policy "unblock own" on public.blocks for delete to authenticated using(blocker_id=(select auth.uid()));

-- Messages are readable to their participants; sender must have accepted friendship
-- OR reciprocal dating likes while BOTH profiles remain opted in. Blocking prevents sends.
create policy "messages participants read" on public.messages for select to authenticated using(sender_id=(select auth.uid()) or recipient_id=(select auth.uid()));
create policy "send only to connected users" on public.messages for insert to authenticated with check (
 sender_id=(select auth.uid())
 and not exists (select 1 from public.blocks b where
  (b.blocker_id=sender_id and b.blocked_id=recipient_id) or
  (b.blocker_id=recipient_id and b.blocked_id=sender_id))
 and (
  exists(select 1 from public.connections c where c.status='accepted' and
    ((c.sender_id=sender_id and c.receiver_id=recipient_id) or (c.sender_id=recipient_id and c.receiver_id=sender_id)))
  or (
   exists(select 1 from public.dating_likes d where d.liker_id=sender_id and d.liked_id=recipient_id)
   and exists(select 1 from public.dating_likes d where d.liker_id=recipient_id and d.liked_id=sender_id)
   and exists(select 1 from public.profiles p where p.id=sender_id and p.dating_enabled and p.adult_confirmed)
   and exists(select 1 from public.profiles p where p.id=recipient_id and p.dating_enabled and p.adult_confirmed)
  )
 )
);

create policy "report own" on public.reports for insert to authenticated with check(reporter_id=(select auth.uid()));
create policy "reporter sees own" on public.reports for select to authenticated using(reporter_id=(select auth.uid()));

-- Realtime private chats: add the messages table to the Supabase realtime publication.
do $$ begin
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='messages') then
  alter publication supabase_realtime add table public.messages;
 end if;
end $$;
