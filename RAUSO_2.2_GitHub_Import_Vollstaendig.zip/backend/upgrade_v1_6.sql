-- Apply after schema.sql and security_v1_2.sql in a NEW dedicated RAUSO Supabase project.
-- No client-side admin grants. Assign admin with SQL Editor separately after verifying owner UUID.
create table if not exists public.app_admins(user_id uuid primary key references auth.users(id) on delete cascade,created_at timestamptz default now());
alter table public.app_admins enable row level security;
create policy "read own admin membership" on public.app_admins for select to authenticated using(user_id=(select auth.uid()));
create table if not exists public.profile_photos(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,storage_path text not null unique,created_at timestamptz default now());
alter table public.profile_photos enable row level security;
create policy "public profile photo metadata" on public.profile_photos for select to authenticated using(true);
create policy "upload own photo metadata" on public.profile_photos for insert to authenticated with check(user_id=(select auth.uid()));
create policy "delete own photo metadata" on public.profile_photos for delete to authenticated using(user_id=(select auth.uid()));
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('profile-photos','profile-photos',true,5242880,array['image/jpeg','image/png','image/webp']) on conflict (id) do nothing;
create policy "upload own profile photos" on storage.objects for insert to authenticated with check(bucket_id='profile-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy "view profile photos" on storage.objects for select to authenticated using(bucket_id='profile-photos');
create policy "delete own profile photos" on storage.objects for delete to authenticated using(bucket_id='profile-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
create table if not exists public.wishlists(id uuid primary key default gen_random_uuid(),created_by uuid not null references auth.users(id) on delete cascade,title text not null check(length(title) between 1 and 80),visibility text not null default 'private' check(visibility in('private','shared')),created_at timestamptz default now());
create table if not exists public.wishlist_members(wishlist_id uuid not null references public.wishlists(id) on delete cascade,user_id uuid not null references auth.users(id) on delete cascade,primary key(wishlist_id,user_id));
create table if not exists public.wishlist_items(id uuid primary key default gen_random_uuid(),wishlist_id uuid not null references public.wishlists(id) on delete cascade,added_by uuid not null references auth.users(id),place_id text,place_name text not null check(length(place_name) between 1 and 120),notes text not null default '',created_at timestamptz default now());
alter table public.wishlists enable row level security;alter table public.wishlist_members enable row level security;alter table public.wishlist_items enable row level security;
create policy "read member wishlists" on public.wishlists for select to authenticated using(created_by=(select auth.uid()) or exists(select 1 from public.wishlist_members m where m.wishlist_id=id and m.user_id=(select auth.uid())));
create policy "create own wishlists" on public.wishlists for insert to authenticated with check(created_by=(select auth.uid()));
create policy "owner changes wishlists" on public.wishlists for update to authenticated using(created_by=(select auth.uid())) with check(created_by=(select auth.uid()));
create policy "owner deletes wishlists" on public.wishlists for delete to authenticated using(created_by=(select auth.uid()));
create policy "read own or owner list membership" on public.wishlist_members for select to authenticated using(user_id=(select auth.uid()) or exists(select 1 from public.wishlists w where w.id=wishlist_id and w.created_by=(select auth.uid())));
create policy "owner invites accepted friends" on public.wishlist_members for insert to authenticated with check(exists(select 1 from public.wishlists w where w.id=wishlist_id and w.created_by=(select auth.uid())) and exists(select 1 from public.connections c where c.status='accepted' and ((c.sender_id=(select auth.uid()) and c.receiver_id=user_id) or (c.receiver_id=(select auth.uid()) and c.sender_id=user_id))));
create policy "remove own or invited member" on public.wishlist_members for delete to authenticated using(user_id=(select auth.uid()) or exists(select 1 from public.wishlists w where w.id=wishlist_id and w.created_by=(select auth.uid())));
create policy "members read items" on public.wishlist_items for select to authenticated using(exists(select 1 from public.wishlists w where w.id=wishlist_id and (w.created_by=(select auth.uid()) or exists(select 1 from public.wishlist_members m where m.wishlist_id=w.id and m.user_id=(select auth.uid())))));
create policy "members add items" on public.wishlist_items for insert to authenticated with check(added_by=(select auth.uid()) and exists(select 1 from public.wishlists w where w.id=wishlist_id and (w.created_by=(select auth.uid()) or exists(select 1 from public.wishlist_members m where m.wishlist_id=w.id and m.user_id=(select auth.uid())))));
create policy "owner or creator removes item" on public.wishlist_items for delete to authenticated using(added_by=(select auth.uid()) or exists(select 1 from public.wishlists w where w.id=wishlist_id and w.created_by=(select auth.uid())));
create table if not exists public.notifications(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,type text not null,body text not null default '',is_read boolean not null default false,created_at timestamptz default now());
alter table public.notifications enable row level security;
create policy "read own notifications" on public.notifications for select to authenticated using(user_id=(select auth.uid()));
create policy "mark own notifications" on public.notifications for update to authenticated using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));
-- Only trusted backend functions / service worker may create notifications.
alter table public.reports add column if not exists status text not null default 'open' check(status in('open','reviewing','resolved'));
-- Old reports table has reason rather than category/description.
create policy "admin reads reports" on public.reports for select to authenticated using(exists(select 1 from public.app_admins a where a.user_id=(select auth.uid())));
create policy "admin updates reports" on public.reports for update to authenticated using(exists(select 1 from public.app_admins a where a.user_id=(select auth.uid()))) with check(exists(select 1 from public.app_admins a where a.user_id=(select auth.uid())));
-- Initial admin assignment from SQL editor only: INSERT INTO public.app_admins(user_id) VALUES ('REAL-OWNER-UUID');
