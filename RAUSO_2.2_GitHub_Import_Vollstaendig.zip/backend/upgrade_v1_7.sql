-- RAUSO 1.7: run AFTER schema.sql, security_v1_2.sql, upgrade_v1_6.sql.
-- SECURITY DEFINER is required to serialize capacity checks; access limited to authenticated.
create or replace function public.set_outing_reaction(p_outing_id uuid, p_reaction text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare v_uid uuid := auth.uid(); v_capacity integer; v_author uuid; v_start timestamptz; v_count integer; v_previous text;
begin
 if v_uid is null then raise exception 'Bitte anmelden'; end if;
 if p_reaction is not null and p_reaction not in ('like','interested','going') then raise exception 'Ungültige Reaktion'; end if;
 -- Row lock serializes all modifications affecting capacity.
 select capacity,author_id,starts_at into v_capacity,v_author,v_start from public.outings where id=p_outing_id for update;
 if not found then raise exception 'Treffen nicht gefunden'; end if;
 if p_reaction='going' and v_start<now() then raise exception 'Das Treffen liegt in der Vergangenheit'; end if;
 select reaction into v_previous from public.outing_reactions where outing_id=p_outing_id and user_id=v_uid;
 if p_reaction='going' and v_previous is distinct from 'going' and v_capacity is not null then
  select count(*) into v_count from public.outing_reactions where outing_id=p_outing_id and reaction='going';
  if v_count+1+(case when v_author=v_uid then 0 else 1 end)>v_capacity then raise exception 'Dieses Treffen ist bereits ausgebucht'; end if;
 end if;
 if p_reaction is null then
   delete from public.outing_reactions where outing_id=p_outing_id and user_id=v_uid;
 else
   insert into public.outing_reactions(outing_id,user_id,reaction) values(p_outing_id,v_uid,p_reaction)
   on conflict (outing_id,user_id) do update set reaction=excluded.reaction;
 end if;
 if v_author<>v_uid and p_reaction='going' and v_previous is distinct from 'going' then
  insert into public.notifications(user_id,type,body)
   values(v_author,'Treffenzusage','Eine Person hat bei deinem Treffen zugesagt.');
 end if;
end $$;
revoke all on function public.set_outing_reaction(uuid,text) from public,anon;
grant execute on function public.set_outing_reaction(uuid,text) to authenticated;
-- Disallow direct writes bypassing the capacity-safe function.
revoke insert,update,delete on public.outing_reactions from authenticated;
-- Backstop: prevent unlimited notifications on an account.
create index if not exists notifications_user_created_idx on public.notifications(user_id,created_at desc);
