-- RAUSO 1.8: two explicitly authorized operators, no concealed rights.
-- Apply only to a SEPARATE RAUSO Supabase project after 1.7.
-- Admin assignment is performed by the database owner, never from client state.
ALTER TABLE public.app_admins ADD COLUMN IF NOT EXISTS role text NOT NULL DEFAULT 'admin';
ALTER TABLE public.app_admins ADD CONSTRAINT rauso_admin_role_check CHECK (role IN ('owner','admin'));
CREATE UNIQUE INDEX IF NOT EXISTS rauso_single_owner ON public.app_admins ((role)) WHERE role='owner';
COMMENT ON TABLE public.app_admins IS 'Visible RAUSO operators; owner manages the service, admin moderates. No hidden operator.';
-- Do not allow app clients to insert/update/delete membership records.
REVOKE INSERT,UPDATE,DELETE ON public.app_admins FROM anon,authenticated;
-- Existing RLS allows each operator to see their own role.
-- Example (run in privileged SQL editor AFTER both people have registered):
-- INSERT INTO public.app_admins(user_id,role) VALUES ('WIFE_AUTH_UUID','owner');
-- INSERT INTO public.app_admins(user_id,role) VALUES ('YOUR_AUTH_UUID','admin');
-- DO NOT paste example UUID values or put administrator credentials in the APK.
